
package com.upgrad.recipieappbysachin.foodsapp.view.home;

import com.upgrad.recipieappbysachin.foodsapp.model.Categories;
import com.upgrad.recipieappbysachin.foodsapp.model.Meals;

import java.util.List;

public interface HomeView {
    void showLoading();
    void hideLoading();
    void setMeal(List<Meals.Meal> meal);
    void setCategory(List<Categories.Category> category);
    void onErrorLoading(String message);


}
