
package com.upgrad.recipieappbysachin.foodsapp.view.detail;

import com.upgrad.recipieappbysachin.foodsapp.model.Meals;
import com.upgrad.recipieappbysachin.foodsapp.model.Meals;

public interface DetailView {
    void showLoading();
    void hideLoading();


    void setMeal(Meals.Meal meal);

    void onErrorLoading(String message);
}
